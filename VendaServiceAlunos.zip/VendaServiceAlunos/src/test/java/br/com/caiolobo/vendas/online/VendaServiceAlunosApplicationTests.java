package br.com.caiolobo.vendas.online;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendaServiceAlunosApplicationTests {

	@Test
	void contextLoads() {
	}

}
